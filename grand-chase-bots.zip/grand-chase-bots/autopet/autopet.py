import sys
import pyautogui
import keyboard
import time

banco = ('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\life.png')

def poc():
    global found_life
    found_life = 'kkkk'
    print('found_life', found_life)

print("Deseja iniciar o processo? (s/n)")

while True: 
    keyboard.read_event()

    if keyboard.is_pressed('n'):
        print("Até a próxima!")
        sys.exit()

    if keyboard.is_pressed('s'):
        print("Bem-vindo ao pet master 3000!\nPressione >s< para iniciar a automação e >n< para parar")
        time.sleep(1)
    
        while True:
            keyboard.read_event()
            if keyboard.is_pressed('s'):
                print("começou")
                break

        while True:
            found_life = False  # Variável para controlar se uma vida foi encontrada

            vida = pyautogui.locateOnScreen(banco, confidence=0.86)
            if vida is not None:
                found_life = True
                keyboard.press('shift')
                time.sleep(0.1)
                keyboard.release('shift')

                time.sleep(7)

                if keyboard.is_pressed('n'):
                    print("Parando a automação...")
                    print("Deseja re-iniciar o processo? (s/n)")
                    break

            if keyboard.is_pressed('n'):
                print("Parando a automação...")
                time.sleep(1)
                print("Deseja re-iniciar o processo? (s/n)")
                break