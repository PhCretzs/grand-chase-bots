import time
import win32api
import win32con
import random
import pyautogui

tempo_de_espera = 5

for i in range(tempo_de_espera, 0, -1):
    print(f"Você tem: {i} segundo(s) para mudar a tela")
    time.sleep(1)

print("\nIniciando o programa...\n")

# Posições declaradas globalmente pois sao utilizadas em todo o código
posicao_x = None
posicao_y = None
posicao_x2 = None
posicao_y2 = None
posicao_x3 = None
posicao_y3 = None

def locate_on_screen(path, grayscale=True, confidence=0.5):
    return pyautogui.locateOnScreen(path, grayscale=grayscale, confidence=confidence)

characters = {
    'elesis': 'C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\elesis.png',
    'lire': '',
    'ryan': ''
}

# Localizar o primeiro ícone (Elesis)
# posicao_icone = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\elesis.png', grayscale = True, confidence = 0.5)
posicao_icone = locate_on_screen(characters.get("elesis"))

if posicao_icone is not None: # Se o ícone for localizado
    print("Posição do primeiro ícone Localizada!")
    posicao_centro = pyautogui.center(posicao_icone) # Pega a posição do centro do icone em relação a tela
    posicao_x = posicao_centro[0] # Eixo X
    posicao_y = posicao_centro[1] # Eixo Y
    print("Primeiro X:", posicao_x)
    print("Primeiro Y:", posicao_y,"\n")
else: # Caso não seja localizado
    print("Não vejo o Primeiro ícone.\n")

# Localizar o segundo ícone (Lire)
posicao_icone2 = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\lire.png', grayscale = True, confidence = 0.5)

if posicao_icone2 is not None: # Se o ícone for localizado
    print("Posição do segundo icone Localizada!")
    posicao_centro2 = pyautogui.center(posicao_icone2) # Pega a posição do centro do icone em relação a tela
    posicao_x2 = posicao_centro2[0] # Eixo X
    posicao_y2 = posicao_centro2[1] # Eixo Y
    print("Segundo X:", posicao_x2)
    print("Segundo Y:", posicao_y2,"\n")
else: # Caso não seja localizado
    print("Não vejo o Segundo ícone.\n")

# Localizar o terceiro ícone (dio)
posicao_icone3 = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\dio.png', grayscale = True, confidence = 0.5)

if posicao_icone3 is not None: # Se o ícone for localizado
    print("Posição do terceiro icone Localizada!")
    posicao_centro3 = pyautogui.center(posicao_icone3) # Pega a posição do centro do icone em relação a tela
    posicao_x3 = posicao_centro3[0] # Eixo X
    posicao_y3 = posicao_centro3[1] # Eixo Y
    print("Terceiro X:", posicao_x3)
    print("Terceiro Y:", posicao_y3,"\n")
else: # Caso não seja localizado
    print("Não vejo o Terceiro ícone.\n")

if posicao_x is not None and posicao_x2 is not None and posicao_y3 is not None: # Se as posições de todos os ícones existirem

    #Tempo aleatório baseado na reação humana
    tempo = random.uniform(0.1, 0.2)
    tempo_de_movimento = random.uniform(0.8, 1.5)

    def click(x, y): # Função do clique (Não entendi muito...)
        win32api.SetCursorPos((x, y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
        time.sleep(tempo) # Descançar né
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)

    distancia = posicao_x2 - posicao_x # Distância entre centros dos ícones
    print("Distância de píxel da primeira linha será:", distancia,"\n")

    print("Primeira linha!\n")

    i = 1
    while i < 11: # Loop da primeira linha
        print("Estou no personagem", i,"\n")
        time.sleep(tempo_de_movimento)
        click(posicao_x, posicao_y)
        time.sleep(tempo)
        click(posicao_x, posicao_y)
        time.sleep(8)

        #Localizar o menu
        posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

        if posicao_menu is not None: # Se o menu for localizado
            print("Posição do menu Localizada!")
            posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
            posicao_xm = posicao_centromenu[0] # Eixo X
            posicao_ym = posicao_centromenu[1] # Eixo Y
            print("Menu X:", posicao_xm)
            print("Menu Y:", posicao_ym,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo o menu.")
            print("\nParei no personagem", i,", selecionei o personagem", i," mas não achei o menu")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xm, posicao_ym)
        time.sleep(tempo)
        click(posicao_xm, posicao_ym)

        posicao_diario = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\diario.png', grayscale = True, confidence = 0.5)

        if posicao_diario is not None: # Se o diário for localizado
            print("Posição do diário Localizada!")
            posicao_centrodiario = pyautogui.center(posicao_diario) # Pega a posição do centro do diário em relação a tela
            posicao_xd = posicao_centrodiario[0] # Eixo X
            posicao_yd = posicao_centrodiario[1] # Eixo Y
            print("Diário X:", posicao_xd)
            print("Diário Y:", posicao_yd,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo o Diário.")
            print("\nParei no personagem", i,", selecionei o menu mas não achei o Diário")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xd, posicao_yd)
        time.sleep(tempo)
        click(posicao_xd, posicao_yd)

        time.sleep(1810) #Esperar 30 minutos 

        posicao_presenca = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\presenca.png', grayscale = True, confidence = 0.5)

        if posicao_presenca is not None: # Se a presença for localizado
            print("Posição da Presença Localizada!")
            posicao_centropresenca = pyautogui.center(posicao_presenca) # Pega a posição do centro da presença em relação a tela
            posicao_xp = posicao_centropresenca[0] # Eixo X
            posicao_yp = posicao_centropresenca[1] # Eixo Y
            print("Presença X:", posicao_xp)
            print("Presença Y:", posicao_yp,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo a Presença.")
            print("\nParei no personagem", i,", selecionei o Diário mas não achei a presença")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xp, posicao_yp)
        time.sleep(tempo)
        click(posicao_xp, posicao_yp)

        k=1
        while k<5:

            posicao_confirmar = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\confirmar.png', grayscale = True, confidence = 0.5)

            if posicao_confirmar is not None: # Se o confirmar for localizado
                print("Posição do Confirmar Localizada!")
                posicao_centroconfirmar = pyautogui.center(posicao_confirmar) # Pega a posição do centro do confirmar em relação a tela
                posicao_xc = posicao_centroconfirmar[0] # Eixo X
                posicao_yc = posicao_centroconfirmar[1] # Eixo Y
                print("Confirmar X:", posicao_xc)
                print("Confirmar Y:", posicao_yc,"\n")
            else: # Caso não seja localizado
                print("\nNão vejo o confirmar.")
                print("\nParei no personagem", i,", selecionei a presença mas não achei o confirmar, loop =", k,)
                break

            time.sleep(tempo_de_movimento)
            click(posicao_xc, posicao_yc)
            time.sleep(tempo)
            click(posicao_xc, posicao_yc)

            time.sleep(2)
            k += 1
        
        posicao_xis = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\xis.png', grayscale = True, confidence = 0.5)

        if posicao_xis is not None: # Se o xis for localizado
            print("Posição do xis Localizada!")
            posicao_centroxis = pyautogui.center(posicao_xis) # Pega a posição do centro do xis em relação a tela
            posicao_xxis = posicao_centroxis[0] # Eixo X
            posicao_yxis = posicao_centroxis[1] # Eixo Y
            print("Xis X:", posicao_xxis)
            print("xis Y:", posicao_yxis,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo o xis.")
            print("\nParei no personagem", i,", selecionei o confirmar mas não achei o xis")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xxis, posicao_yxis)
        time.sleep(tempo)
        click(posicao_xxis, posicao_yxis)

        #Localizar o menu
        posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

        if posicao_menu is not None: # Se o menu for localizado
            print("Posição do menu Localizada!")
            posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
            posicao_xm = posicao_centromenu[0] # Eixo X
            posicao_ym = posicao_centromenu[1] # Eixo Y
            print("Menu X:", posicao_xm)
            print("Menu Y:", posicao_ym,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo o menu.")
            print("\nParei no personagem", i,", selecionei o personagem", i," mas não achei o menu")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xm, posicao_ym)
        time.sleep(tempo)
        click(posicao_xm, posicao_ym)

        #Localizar a seleção de personagens
        posicao_sele = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\selecionar.png', grayscale = True, confidence = 0.5)

        if posicao_sele is not None: # Se a seleção de personagens for localizada
            print("Posição da seleção Localizada!")
            posicao_centros = pyautogui.center(posicao_sele) # Pega a posição do centro da seleção em relação a tela
            posicao_xs = posicao_centros[0] # Eixo X
            posicao_ys = posicao_centros[1] # Eixo Y
            print("Seleção X:", posicao_xs)
            print("Seleção Y:", posicao_ys,"\n")
        else: # Caso não seja localizado
            print("\nNão vejo a seleção de personagens.")
            print("\nParei no personagem", i,", selecionei o menu mas não achei a seleção de personagens")
            break

        time.sleep(tempo_de_movimento)
        click(posicao_xs, posicao_ys)
        time.sleep(tempo)
        click(posicao_xs, posicao_ys)
        time.sleep(2)
        

        posicao_x += distancia
        i += 1
        Xcontrole = posicao_x3
        if i == 11:
            print("\nSegunda Linha!\n")

            i = 11
            while i < 21: # Loop da segunda linha
                print("Estou no personagem", i,"\n")
                time.sleep(tempo_de_movimento)
                click(posicao_x3, posicao_y3)
                time.sleep(tempo)
                click(posicao_x3, posicao_y3)
                time.sleep(8)

                #Localizar o menu
                posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

                if posicao_menu is not None: # Se o menu for localizado
                    print("Posição do menu Localizada!")
                    posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
                    posicao_xm = posicao_centromenu[0] # Eixo X
                    posicao_ym = posicao_centromenu[1] # Eixo Y
                    print("Menu X:", posicao_xm)
                    print("Menu Y:", posicao_ym,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo o menu.")
                    print("\nParei no personagem", i,", selecionei o personagem", i," mas não achei o menu")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xm, posicao_ym)
                time.sleep(tempo)
                click(posicao_xm, posicao_ym)

                posicao_diario = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\diario.png', grayscale = True, confidence = 0.5)

                if posicao_diario is not None: # Se o diário for localizado
                    print("Posição do diário Localizada!")
                    posicao_centrodiario = pyautogui.center(posicao_diario) # Pega a posição do centro do diário em relação a tela
                    posicao_xd = posicao_centrodiario[0] # Eixo X
                    posicao_yd = posicao_centrodiario[1] # Eixo Y
                    print("Diário X:", posicao_xd)
                    print("Diário Y:", posicao_yd,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo o Diário.")
                    print("\nParei no personagem", i,", selecionei o menu mas não achei o Diário")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xd, posicao_yd)
                time.sleep(tempo)
                click(posicao_xd, posicao_yd)

                time.sleep(1810) #Esperar 30 minutos 

                posicao_presenca = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\presenca.png', grayscale = True, confidence = 0.5)

                if posicao_presenca is not None: # Se a presença for localizado
                    print("Posição da Presença Localizada!")
                    posicao_centropresenca = pyautogui.center(posicao_presenca) # Pega a posição do centro da presença em relação a tela
                    posicao_xp = posicao_centropresenca[0] # Eixo X
                    posicao_yp = posicao_centropresenca[1] # Eixo Y
                    print("Presença X:", posicao_xp)
                    print("Presença Y:", posicao_yp,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo a Presença.")
                    print("\nParei no personagem", i,", selecionei o Diário mas não achei a presença")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xp, posicao_yp)
                time.sleep(tempo)
                click(posicao_xp, posicao_yp)

                k=1
                while k<5:

                    posicao_confirmar = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\confirmar.png', grayscale = True, confidence = 0.5)

                    if posicao_confirmar is not None: # Se o confirmar for localizado
                        print("Posição do Confirmar Localizada!")
                        posicao_centroconfirmar = pyautogui.center(posicao_confirmar) # Pega a posição do centro do confirmar em relação a tela
                        posicao_xc = posicao_centroconfirmar[0] # Eixo X
                        posicao_yc = posicao_centroconfirmar[1] # Eixo Y
                        print("Confirmar X:", posicao_xc)
                        print("Confirmar Y:", posicao_yc,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo o confirmar.")
                        print("\nParei no personagem", i,", selecionei a presença mas não achei o confirmar, loop =", k,)
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xc, posicao_yc)
                    time.sleep(tempo)
                    click(posicao_xc, posicao_yc)

                    time.sleep(2)
                    k += 1
                
                posicao_xis = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\xis.png', grayscale = True, confidence = 0.5)

                if posicao_xis is not None: # Se o xis for localizado
                    print("Posição do xis Localizada!")
                    posicao_centroxis = pyautogui.center(posicao_xis) # Pega a posição do centro do xis em relação a tela
                    posicao_xxis = posicao_centroxis[0] # Eixo X
                    posicao_yxis = posicao_centroxis[1] # Eixo Y
                    print("Xis X:", posicao_xxis)
                    print("xis Y:", posicao_yxis,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo o xis.")
                    print("\nParei no personagem", i,", selecionei o confirmar mas não achei o xis")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xxis, posicao_yxis)
                time.sleep(tempo)
                click(posicao_xxis, posicao_yxis)

                #Localizar o menu
                posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

                if posicao_menu is not None: # Se o menu for localizado
                    print("Posição do menu Localizada!")
                    posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
                    posicao_xm = posicao_centromenu[0] # Eixo X
                    posicao_ym = posicao_centromenu[1] # Eixo Y
                    print("Menu X:", posicao_xm)
                    print("Menu Y:", posicao_ym,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo o menu.")
                    print("\nParei no personagem", i,", selecionei o personagem", i," mas não achei o menu")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xm, posicao_ym)
                time.sleep(tempo)
                click(posicao_xm, posicao_ym)

                #Localizar a seleção de personagens
                posicao_sele = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\selecionar.png', grayscale = True, confidence = 0.5)

                if posicao_sele is not None: # Se a seleção de personagens for localizada
                    print("Posição da seleção Localizada!")
                    posicao_centros = pyautogui.center(posicao_sele) # Pega a posição do centro da seleção em relação a tela
                    posicao_xs = posicao_centros[0] # Eixo X
                    posicao_ys = posicao_centros[1] # Eixo Y
                    print("Seleção X:", posicao_xs)
                    print("Seleção Y:", posicao_ys,"\n")
                else: # Caso não seja localizado
                    print("\nNão vejo a seleção de personagens.")
                    print("\nParei no personagem", i,", selecionei o menu mas não achei a seleção de personagens")
                    break

                time.sleep(tempo_de_movimento)
                click(posicao_xs, posicao_ys)
                time.sleep(tempo)
                click(posicao_xs, posicao_ys)
                time.sleep(2)
                
                posicao_x3 += distancia

                if i == 20:
                    print("\nPeryton!\n")

                    print("Estou no Peryton\n")
                    time.sleep(tempo_de_movimento)
                    distanciay = posicao_y3 - posicao_y
                    y = posicao_y3 + distanciay
                    click(Xcontrole, y)
                    time.sleep(tempo)
                    click(Xcontrole, y)
                    time.sleep(8)

                    #Localizar o menu
                    posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

                    if posicao_menu is not None: # Se o menu for localizado
                        print("Posição do menu Localizada!")
                        posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
                        posicao_xm = posicao_centromenu[0] # Eixo X
                        posicao_ym = posicao_centromenu[1] # Eixo Y
                        print("Menu X:", posicao_xm)
                        print("Menu Y:", posicao_ym,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo o menu.")
                        print("Parei no Peryton, selecionei o Peryton mas nao achei o menu")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xm, posicao_ym)
                    time.sleep(tempo)
                    click(posicao_xm, posicao_ym)

                    posicao_diario = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\diario.png', grayscale = True, confidence = 0.5)

                    if posicao_diario is not None: # Se o diário for localizado
                        print("Posição do diário Localizada!")
                        posicao_centrodiario = pyautogui.center(posicao_diario) # Pega a posição do centro do diário em relação a tela
                        posicao_xd = posicao_centrodiario[0] # Eixo X
                        posicao_yd = posicao_centrodiario[1] # Eixo Y
                        print("Diário X:", posicao_xd)
                        print("Diário Y:", posicao_yd,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo o Diário.")
                        print("\nParei no Peryton, selecionei o menu mas não achei o Diário")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xd, posicao_yd)
                    time.sleep(tempo)
                    click(posicao_xd, posicao_yd)

                    time.sleep(1810) #Esperar 30 minutos 

                    posicao_presenca = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\presenca.png', grayscale = True, confidence = 0.5)

                    if posicao_presenca is not None: # Se a presença for localizado
                        print("Posição da Presença Localizada!")
                        posicao_centropresenca = pyautogui.center(posicao_presenca) # Pega a posição do centro da presença em relação a tela
                        posicao_xp = posicao_centropresenca[0] # Eixo X
                        posicao_yp = posicao_centropresenca[1] # Eixo Y
                        print("Presença X:", posicao_xp)
                        print("Presença Y:", posicao_yp,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo a Presença.")
                        print("\nParei no Peryton, selecionei o Diário mas não achei a presença")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xp, posicao_yp)
                    time.sleep(tempo)
                    click(posicao_xp, posicao_yp)

                    k=1
                    while k<5:

                        posicao_confirmar = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\confirmar.png', grayscale = True, confidence = 0.5)

                        if posicao_confirmar is not None: # Se o confirmar for localizado
                            print("Posição do Confirmar Localizada!")
                            posicao_centroconfirmar = pyautogui.center(posicao_confirmar) # Pega a posição do centro do confirmar em relação a tela
                            posicao_xc = posicao_centroconfirmar[0] # Eixo X
                            posicao_yc = posicao_centroconfirmar[1] # Eixo Y
                            print("Confirmar X:", posicao_xc)
                            print("Confirmar Y:", posicao_yc,"\n")
                        else: # Caso não seja localizado
                            print("\nNão vejo o confirmar.")
                            print("\nParei no Peryton, selecionei a presença mas não achei o confirmar, loop =", k,)
                            break

                        time.sleep(tempo_de_movimento)
                        click(posicao_xc, posicao_yc)
                        time.sleep(tempo)
                        click(posicao_xc, posicao_yc)

                        time.sleep(2)
                        k += 1
                    
                    posicao_xis = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\xis.png', grayscale = True, confidence = 0.5)

                    if posicao_xis is not None: # Se o xis for localizado
                        print("Posição do xis Localizada!")
                        posicao_centroxis = pyautogui.center(posicao_xis) # Pega a posição do centro do xis em relação a tela
                        posicao_xxis = posicao_centroxis[0] # Eixo X
                        posicao_yxis = posicao_centroxis[1] # Eixo Y
                        print("Xis X:", posicao_xxis)
                        print("xis Y:", posicao_yxis,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo o xis.")
                        print("\nParei no Peryton, selecionei o confirmar mas não achei o xis")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xxis, posicao_yxis)
                    time.sleep(tempo)
                    click(posicao_xxis, posicao_yxis)

                    #Localizar o menu
                    posicao_menu = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\menu.png', grayscale = True, confidence = 0.5)

                    if posicao_menu is not None: # Se o menu for localizado
                        print("Posição do menu Localizada!")
                        posicao_centromenu = pyautogui.center(posicao_menu) # Pega a posição do centro do menu em relação a tela
                        posicao_xm = posicao_centromenu[0] # Eixo X
                        posicao_ym = posicao_centromenu[1] # Eixo Y
                        print("Menu X:", posicao_xm)
                        print("Menu Y:", posicao_ym,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo o menu.")
                        print("\nParei no Peryton, selecionei o personagem", i," mas não achei o menu")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xm, posicao_ym)
                    time.sleep(tempo)
                    click(posicao_xm, posicao_ym)

                    #Localizar a seleção de personagens
                    posicao_sele = pyautogui.locateOnScreen('C:\\Users\\phcre\\OneDrive\\Imagens\\Capturas de tela\\selecionar.png', grayscale = True, confidence = 0.5)

                    if posicao_sele is not None: # Se a seleção de personagens for localizada
                        print("Posição da seleção Localizada!")
                        posicao_centros = pyautogui.center(posicao_sele) # Pega a posição do centro da seleção em relação a tela
                        posicao_xs = posicao_centros[0] # Eixo X
                        posicao_ys = posicao_centros[1] # Eixo Y
                        print("Seleção X:", posicao_xs)
                        print("Seleção Y:", posicao_ys,"\n")
                    else: # Caso não seja localizado
                        print("\nNão vejo a seleção de personagens.")
                        print("\nParei no Peryton, selecionei o menu mas não achei a seleção de personagens")
                        break

                    time.sleep(tempo_de_movimento)
                    click(posicao_xs, posicao_ys)
                    time.sleep(tempo)
                    click(posicao_xs, posicao_ys)
                    time.sleep(2)

                    print("\nAcabou...")

                i += 1

else:
    print("\nImpossível rodar. Tente novamente com os ícones na janela principal.")