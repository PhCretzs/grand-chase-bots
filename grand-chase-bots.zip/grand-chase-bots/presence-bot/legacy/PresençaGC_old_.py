import time
import keyboard
import win32api, win32con

# Q mata a tarefa
while keyboard.is_pressed('q') == False: 

    # tempo para alt+tab
    time.sleep(2)

    def click(x,y):
        win32api.SetCursorPos((x,y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
        time.sleep(0.1)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)

    # Valor inicial de x
    x = 510 

    # Número de iteraçoes
    num_it = 10

    # Loop (Primeira linha)
    i = 0
    while i < num_it: 
            
        # Selecionar o char (elesis)
        click (x,700)
        time.sleep(0.1)
        click (x,700)

        # Esperar
        time.sleep(4)

        # Selecionar o menu
        click (1675,82)
        time.sleep(0.1)
        click (1675,82)

        #Esperar
        time.sleep(2)

        # Selecionar o diario
        click (1257,401)
        time.sleep(0.1)
        click (1257,401)

        # Esperar (30 min)
        time.sleep(1810)

        # Marcar presença
        click (730,655)
        time.sleep(0.1)
        click (730,655)

        #Esperar
        time.sleep(2)

        #Ok
        click (1000,600)
        time.sleep(0.1)
        click (1000,600)

        #Esperar
        time.sleep(2)

        #VP
        click (987,710)
        time.sleep(0.1)
        click (987,710)

        #Esperar
        time.sleep(2)

        #Ticket heroico
        click (987,710)
        time.sleep(0.1)
        click (987,710)

        #Esperar
        time.sleep(2)

        #Ok
        click (1000,600)
        time.sleep(0.1)
        click (1000,600)

        #Esperar
        time.sleep(2)

        # Selecionar o "X"
        click (1174,195)
        time.sleep(0.1)
        click (1174,195)

        #Esperar
        time.sleep(2)

        # Selecionar o menu
        click (1675,82)
        time.sleep(0.1)
        click (1675,82)

        #Esperar
        time.sleep(2)

        # Selecionar Troca de char
        click (1100,800)
        time.sleep(0.1)
        click (1100,800)

        #Esperar
        time.sleep(2)

        # Aumentar o valor de x em 100
        x += 100

        # Adicionar a contagem
        i += 1

    # Loop (Segunda linha)

    # Valor inicial de x
    y = 510 

    # Número de iteraçoes
    num_it2 = 10

    j = 0
    while j < num_it2: 

        # Selecionar o char (Dio)
        click (y,800)
        time.sleep(0.1)
        click (y,800)

        # Esperar
        time.sleep(4)

        # Selecionar o menu
        click (1675,82)
        time.sleep(0.1)
        click (1675,82)

        #Esperar
        time.sleep(2)

        # Selecionar o diario
        click (1257,401)
        time.sleep(0.1)
        click (1257,401)

        # Esperar (30 min)
        time.sleep(1810)

        # Marcar presença
        click (730,655)
        time.sleep(0.1)
        click (730,655)

        #Esperar
        time.sleep(2)

        #Ok
        click (1000,600)
        time.sleep(0.1)
        click (1000,600)

        #Esperar
        time.sleep(2)

        #VP
        click (987,710)
        time.sleep(0.1)
        click (987,710)

        #Esperar
        time.sleep(2)

        #Ticket heroico
        click (987,710)
        time.sleep(0.1)
        click (987,710)

        #Esperar
        time.sleep(2)

        #Ok
        click (1000,600)
        time.sleep(0.1)
        click (1000,600)

        #Esperar
        time.sleep(2)

        # Selecionar o "X"
        click (1174,195)
        time.sleep(0.1)
        click (1174,195)

        #Esperar
        time.sleep(2)

        # Selecionar o menu
        click (1675,82)
        time.sleep(0.1)
        click (1675,82)

        #Esperar
        time.sleep(2)

        # Selecionar Troca de char
        click (1100,800)
        time.sleep(0.1)
        click (1100,800)

        #Esperar
        time.sleep(2)

        # Aumentar o valor de x em 100
        y += 100

        # Adicionar a contagem
        j += 1

    # Selecionar o char (Periton)
    click (510,870)
    time.sleep(0.1)
    click (510,870)

    # Esperar
    time.sleep(4)

    # Selecionar o menu
    click (1675,82)
    time.sleep(0.1)
    click (1675,82)

    #Esperar
    time.sleep(2)

    # Selecionar o diario
    click (1257,401)
    time.sleep(0.1)
    click (1257,401)

    # Esperar (30 min)
    time.sleep(1810)

    # Marcar presença
    click (730,655)
    time.sleep(0.1)
    click (730,655)

    #Esperar
    time.sleep(2)

    #Ok
    click (1000,600)
    time.sleep(0.1)
    click (1000,600)

    #Esperar
    time.sleep(2)

    #VP
    click (987,710)
    time.sleep(0.1)
    click (987,710)

    #Esperar
    time.sleep(2)

    #Ticket heroico
    click (987,710)
    time.sleep(0.1)
    click (987,710)

    #Esperar
    time.sleep(2)

    #Ok
    click (1000,600)
    time.sleep(0.1)
    click (1000,600)

    #Esperar
    time.sleep(2)

    #Ok
    click (1000,600)
    time.sleep(0.1)
    click (1000,600)

    #Esperar
    time.sleep(2)

    # Selecionar o "X"
    click (1174,195)
    time.sleep(0.1)
    click (1174,195)

    #Esperar
    time.sleep(2)

    # Selecionar o menu
    click (1675,82)
    time.sleep(0.1)
    click (1675,82)

    #Esperar
    time.sleep(2)

    # Selecionar Troca de char
    click (1100,800)
    time.sleep(0.1)
    click (1100,800)

    #Esperar
    time.sleep(2)