import cv2
import numpy as np
import time
import threading
from pynput.keyboard import Key, Controller
from windowcapture import WindowCapture
from imagerecognition import encontrar_player, encontrar_monstros

wincap = WindowCapture('Harmony v0.4.1')
keyboard = Controller()

player_pos = None
monstro_pos = None
plataformas_pos = []
tela_atual = None
canny_vision = None
running = True
movement_state = {"left": False, "right": False, "jump": False, "attack": False}
lock = threading.Lock()

def mover_personagem():
    global player_pos, monstro_pos, running
    while running:
        if player_pos and monstro_pos:
            px, py = player_pos
            mx, my = monstro_pos
            if px < mx - 150:
                keyboard.press(Key.right)
                time.sleep(0.25)
                keyboard.release(Key.right)
            elif px > mx + 150:
                keyboard.press(Key.left)
                time.sleep(0.25)
                keyboard.release(Key.left)
            else:
                if abs(py - my) <= 100:  # Mesma altura, ataca
                    keyboard.press('z')
                    time.sleep(0.1)
                    keyboard.release('z')
                elif my < py:  # Monstro acima, pula
                    keyboard.press(Key.up)
                    time.sleep(0.1)
                    keyboard.release(Key.up)
                elif my > py:  # Monstro abaixo, abaixa
                    keyboard.press(Key.down)
                    time.sleep(0.1)
                    keyboard.release(Key.down)
        time.sleep(0.01)

movement_thread = threading.Thread(target=mover_personagem, daemon=True)
movement_thread.start()

while True:
    start_time = time.time()
    tela = wincap.get_screenshot()
    with lock:
        tela_atual = tela.copy()
    
    player_pos = encontrar_player(tela)
    monstros_pos = encontrar_monstros(tela)
    
    if player_pos and monstros_pos:
        monstro_pos = min(monstros_pos, key=lambda m: abs(m[0] - player_pos[0]))
    else:
        monstro_pos = None
    
    if player_pos:
        cv2.circle(tela, player_pos, 10, (0, 0, 255), 2)
    for pos in monstros_pos:
        cv2.circle(tela, pos, 10, (0, 255, 255), 2)
    for pos in plataformas_pos:
        cv2.circle(tela, pos, 10, (0, 255, 0), 2)
    
    tela = cv2.resize(tela, (tela.shape[1] // 2, tela.shape[0] // 2), interpolation=cv2.INTER_AREA)
    cv2.imshow("Olhos do robo", tela)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        running = False
        break
    
    # elapsed = time.time() - start_time
    # if elapsed < 0.0167:
    #     time.sleep(0.0167 - elapsed)

cv2.destroyAllWindows()