import numpy as np
import cv2
import win32gui
from mss import mss

class WindowCapture:
    def __init__(self, window_name):
        self.sct = mss()
        self.window_name = window_name
        self.hwnd = win32gui.FindWindow(None, window_name)
        if not self.hwnd:
            raise Exception(f'Janela não encontrada: {window_name}')
        # Pega as coordenadas da janela
        window_rect = win32gui.GetWindowRect(self.hwnd)
        self.region = {
            'left': window_rect[0],
            'top': window_rect[1],
            'width': window_rect[2] - window_rect[0],
            'height': window_rect[3] - window_rect[1]
        }

    def get_screenshot(self):
        # Captura a região da janela
        screenshot = self.sct.grab(self.region)
        # Converte pra array NumPy e BGR
        img = np.array(screenshot)
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
        return img