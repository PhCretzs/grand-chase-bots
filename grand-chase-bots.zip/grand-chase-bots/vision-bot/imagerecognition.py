import cv2
import numpy as np

def encontrar_player(imagem):
    vermelho_exato = np.array([0, 0, 255], dtype=np.uint8)  # BGR pra #FF0000
    mascara = cv2.inRange(imagem, vermelho_exato, vermelho_exato)  # Sem conversão HSV
    contornos, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for cnt in contornos:
        if cv2.contourArea(cnt) > 50:
            x, y, w, h = cv2.boundingRect(cnt)
            cx = x + w // 2
            cy = y + h
            return (cx, cy + 100)
    return None

def encontrar_monstros(imagem):
    amarelo_exato = np.array([0, 210, 255], dtype=np.uint8)  # BGR pra #FFD200
    mascara = cv2.inRange(imagem, amarelo_exato, amarelo_exato)
    contornos, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    posicoes = []
    for cnt in contornos:
        if cv2.contourArea(cnt) > 10:
            x, y, w, h = cv2.boundingRect(cnt)
            posicoes.append((x + w // 2, y - 50))
    return posicoes